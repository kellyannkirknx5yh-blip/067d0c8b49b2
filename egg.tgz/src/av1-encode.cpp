// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Encode AV1 stream");
  std::fflush(stdout);
  return lionss_run_workload("av1-encode");
}
