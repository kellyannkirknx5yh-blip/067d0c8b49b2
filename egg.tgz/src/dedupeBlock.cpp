// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Deduplicate blocks\n", stdout);
  return lionss_run_workload("dedupeBlock");
}
